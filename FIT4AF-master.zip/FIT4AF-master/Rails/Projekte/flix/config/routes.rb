Rails.application.routes.draw do

  root "movies#index"
  
  get 'signup' => 'users#new'
  get 'signin' => 'sessions#new'

  resource :session
  resources :users

  resources :movies do

    collection do
      get 'recent'
      get 'upcoming'
      get 'hits'
      get 'flops'
    end

    resources :reviews
    resources :likes
   
  end
end
