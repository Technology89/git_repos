class LikesController < ApplicationController
	before_action :require_signin
	before_action :set_movie

	def create
		# @movie.likes.create(user: current_user)
		@movie.likers << current_user
		@current_like = current_user.likes.find_by(movie_id: @movie.id)
		respond_to do |format|
			format.html {redirect_to @movie, notice: "Super, kannst dir eine anstecken!"}
			format.js
		end
	end

	def destroy
		@like = current_user.likes.find(params[:id])
		@like.destroy
		respond_to do |format|
			format.html {redirect_to @movie, notice: "Gut gemacht. War ein besch***ener Film."}
		format.js
		
	end

	private
		def set_movie
			@movie = Movie.find(params[:movie_id])
		end	
end
