class ReviewsController < ApplicationController
	before_action :set_movie
	before_action :require_signin

	def index
		@reviews = @movie.reviews
	end

	def show
		@review = Review.find(params[:id])
	end

	def new
		@review = @movie.reviews.new
	end

	def create
		@review = @movie.reviews.new(review_params)
		@review.user_id = current_user.id 
		if @review.save
			flash[:notice] = "Erfolgreich gespeichert."
			redirect_to movies_path(@movie.id), notice: "Die Review wurde gespeichert!"
		else
			render :new, notice: "Fehler beim Speichern!"
		end
	end

	def destroy
		@review = Review.find(params[:id])
		@review.delete
		redirect_to movie_reviews_url(@movie.id), notice: "Review von #{@review.user.name} erfolgreich gelöscht!"
	end

	private
		def review_params
			params.require(:review).permit(:user_id, :stars, :comment, :movie_id)
		end

		def set_movie
			@movie = Movie.find(params[:movie_id])
		end
end

