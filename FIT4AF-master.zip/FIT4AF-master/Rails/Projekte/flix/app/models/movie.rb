class Movie < ActiveRecord::Base
	mount_uploader :poster_image_file, AvatarUploader

	has_many :reviews, dependent: :destroy
	has_many :likes, dependent: :destroy
 	has_many :likers, through: :likes, source: :user
	
	validates :title, :released_on, :duration, presence:true
	validates :description, length: { minimum: 25 }
	validates :total_gross, numericality: { greater_than_or_equal_to: 0 }
	validates :poster_image_file, allow_blank: true, format: 
						{with: /\w+.(gif|jpg|png)\z/i, message: "soll ein GIF, JPG oder PNG Bild sein"}
	validates :rating, inclusion: { in: %w(G PG PG-13 R NC-17)}
	RATING_OPTIONS = ['G', 'PG', 'PG-13', 'R', 'NC-17']

	def flop?
		total_gross < 10000000 unless total_gross.blank?
	end
	
	scope :shown, -> {where("released_on <= ?", Time.now).order("released_on")}

	scope :total_gross, -> {where("total_gross >= 100000000")}

	scope :hits, -> {where("total_gross >= 50000000")}

	scope :flops, -> {where("total_gross <= 50000000")}

	scope :upcoming, -> {where("released_on >= ?", Time.now)}
	
	scope :recent, -> {where("released_on <= ?", Time.now)}

end
