#!/bin/bash

description=$(date +%Y-%m-%d)
git add . -A
git commit -am "$description"
git push origin master
