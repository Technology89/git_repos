class Project < ActiveRecord::Base
	has_many :tasks, dependent: :destroy
	
	validates :title, length: {minimum: 5, message: "muss mindestens 5 Stellen haben"}
	validate :start_date_cannot_be_in_the_past
 
  def start_date_cannot_be_in_the_past
    if start_date < Date.today
      errors.add(:start_date, "darf nicht in der Vergangenheit liegen!")
    end
  end

end
