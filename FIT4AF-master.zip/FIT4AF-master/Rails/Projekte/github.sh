#!/bin/bash

cd ~/Dokumente/FIT4AF/
description=$(date +%Y-%m-%d)
git pull origin master
git add . -A
git commit -am "$description"
git push origin master
