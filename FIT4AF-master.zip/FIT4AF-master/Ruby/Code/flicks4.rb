class Playlist
	def initialize(name)
		@name = name
		@movies = []
	end

	def add_movie(movie)
		@movies << movie
	end

	def play
		puts "Playlist heißt: #{@name.capitalize}"
		@movies.each do |movie|
			movie.thumps_up
			movie.thumps_down
			puts movie
	end

end

class Movie
	attr_reader :title, :rank

	def initialize(ptitle, prank=50)
		@title = ptitle
		@rank = prank
	end

	def title=(ptitle)
		@title = ptitle.capitalize
	end
	
	def normalized_rank
		@rank / 10
	end

	def thumps_up
		@rank = @rank + 10
	end
	
	def thumps_down
		@rank = @rank - 10
	end
	
	def to_s
		"Der Film #{@title} hat den Rank: #{normalized_rank}"
	end
end

movie1 = Movie.new("batman", 40)
movie2 = Movie.new("Superman")
playlist = Playlist.new('Horrorfilme')
playlist.add_movie(movie1)
playlist.add_movie(movie2)
playlist.play
end