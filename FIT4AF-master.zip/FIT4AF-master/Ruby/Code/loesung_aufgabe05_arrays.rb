# a. legen Sie zur uebung auf der irb ein Array jahreszeiten mit den Elementen: Sommer, Herbst, Winter an; 
#    sowohl in der Langform, als auch der Kurzform
# b. lassen Sie ausgeben wieviele Elemente das Array enthaelt, welche Jahreszeit die zweite im Array ist
# c. fuegen Sie das Element fruehjahr hinzu
# d. entfernen Sie das Element wieder aus dem Array
# e. ermitteln Sie mit Hilfe von ri, wie join Ihnen bei einer folgendermassen formatierten Ausgabe behilflich sein kann: 
#    Sommer und Herbst und Winter
# f. notieren Sie den Befehl
# g. ermitteln Sie den Befehl mit dem Sie die Positionen der Elemente des Arrays nach einem Zufallsprinzip 
#    anordnen koennen
# h. packen Sie Ihre drei Player aus dem Projekt in ein Array
# i. Geben Sie Player mit einer Iteration über das Array aus. Beginnen Sie mit einer Zeile, 
#    in der sie die Anzahl der Mitspieler notieren

# # a. 
# 	 Elemente = ["Sommer", "Herbst", "Winter"]
# # b. 
# 	 Elemente.count
# 	 Elemente[1]
# # c. 
# 	 Elemente.push("Fruehjahr")
# # d. 
# 	 Elemente.delete("Fruehjahr")
# # f. 
# 	 Elemente.join(" und ")
# # g.
# 	 Elemente.shuffle
# h.
	 class Player
	attr_accessor :health

	def initialize(pname, phealth=100)
		@name = pname.capitalize
		@health = phealth
	end

	def say_hello
		"Ich bin #{@name} mit einem Wert von #{score}"
	end

	def to_s
		say_hello
	end

	def blam
		@health = @health + 10
		puts "#{@name} got blamed"
	end
	
	def w00t
		@health = @health - 10
		puts "#{@name} got w00ted"
	end

	def score
		@health + @name.length
	end
end

	player1 = Player.new("John",85)
	player2 = Player.new("Jack")
	player3 = Player.new("Jimmy",77)
	players = [player1, player2, player3]

	puts "Anzahl der Spieler: #{players.count}"
	players.each do |player|
	puts player
end