puts "Die \"Woche\" besteht aus:\n\tMontag\n\tDienstag."

var = "Hello Ruby"
var2 = "heute ist der 9.9.2015 + "
var3 = 1
puts var + " " + var2 + var3.to_s

puts "#{var} #{Time.new} #{var3}"